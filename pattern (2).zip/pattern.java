import java.util.Scanner;
public class pattern{
    public static void main(String[] args){
        Scanner row=new Scanner(System.in);
        String str="*";
        int num=row.nextInt();
        int s=num;
        for(int i=0;i<num;i++){
            String result=str.repeat(s);
            System.out.println(result);
            s--;
        }
    }
}