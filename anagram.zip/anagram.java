import java.util.Scanner;
import java.util.Arrays;
public class anagram{
    public static void main(String [] args){
        Scanner s=new Scanner(System.in);
        String str=s.nextLine().replaceAll("\\s", "").toLowerCase();
        String str2=s.nextLine().replaceAll("\\s", "").toLowerCase();
        if (str.length()!=str2.length()){
            System.out.println("They are not anagrams");
        }
        else{
            char [] arr1=str.toCharArray();
            char [] arr2=str2.toCharArray();
           Arrays.sort(arr1);
           Arrays.sort(arr2);
           if (Arrays.equals(arr1,arr2)){
            System.out.println("They are anagrams");
           }else{
            System.out.println("They are not anagrams");
           }

             }

            s.close();
    }
}