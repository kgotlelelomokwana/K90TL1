import java.util.*;

public class DuplicateFinder {
    public static List<Integer> duplicate_finder(int[] arr) {
        Set<Integer> seen = new HashSet<>();
        Set<Integer> duplicates = new HashSet<>();
        
        for (int num : arr) {
            if (!seen.add(num)) {
                duplicates.add(num);
            }
        }
        
        return new ArrayList<>(duplicates);
    }

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        int n=scanner.nextInt();
        int [] arr=new int[n];
        for (int i=0;i<n;i++){
           arr[i]=scanner.nextInt();

        }
        System.out.println(duplicate_finder(arr));
        scanner.close();
    }
}
